self.__precacheManifest = [
  {
    "revision": "220c7be3df8abd26bee7",
    "url": "/static/js/runtime~app.13848ce2.js"
  },
  {
    "revision": "0eec5f808eda185efa4c",
    "url": "/static/js/app.bee5e592.chunk.js"
  },
  {
    "revision": "36108ee74999da31c99e",
    "url": "/static/js/2.8056220f.chunk.js"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "/static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "004c2bbb035d8d06bb830efc4673c886",
    "url": "/static/media/star.004c2bbb.png"
  },
  {
    "revision": "2327736b3ea09c41abfb69be1221f430",
    "url": "/static/media/heart.2327736b.png"
  },
  {
    "revision": "51671417ef20e0bbc32f0a2bc6edfa95",
    "url": "/static/media/rocket.51671417.png"
  },
  {
    "revision": "a7b9dc9de5f8f1fb1afbef917619a5ac",
    "url": "/static/media/bell.a7b9dc9d.png"
  },
  {
    "revision": "1c18727afd98aef9246a770e478b92fe",
    "url": "/static/media/portfolio.1c18727a.jpg"
  },
  {
    "revision": "b038b0b02663a625ada22453b3feacd1",
    "url": "/static/media/ranks.b038b0b0.jpg"
  },
  {
    "revision": "c419ccb52d5687ca916a8e1d6137bb0a",
    "url": "/static/media/shadow-cljs.c419ccb5.png"
  },
  {
    "revision": "bc36d91f1228514f5d9a03fa802a972f",
    "url": "/static/media/daily_questions.bc36d91f.jpg"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "2c19dffa4e2d5a5e061dc783fcceada4",
    "url": "/.expo/packager-info.json"
  },
  {
    "revision": "5d50375768f581c6f61e78f55821b715",
    "url": "/.expo/settings.json"
  },
  {
    "revision": "5f0b7185e20a78bc1e2914085a9a477f",
    "url": "/manifest.json"
  },
  {
    "revision": "33b51492ba6f3ae2c6b02eb68406be08",
    "url": "/index.html"
  }
];